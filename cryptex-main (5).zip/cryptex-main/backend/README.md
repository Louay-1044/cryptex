# Backend
The backend should serve a REST api, for the client to make calls to, currently hosted on port 8000.
Written using Python with Django.

# TODO
## Account managment
Assigned to Ben
* Proccess create/delete account
* Store account
* Store trade history
* Process login/logout
* Process Top up balance

## Organisation Managment
Assigned to Louay
* Process organisation creation/renaming/delation
* Fetch current traders
* View organisation wallet portfolio
* Invite trader to organisation
* Remove trader from organisation
* View trade history of a trader

## Trading View
Assigned to Ben
* Fetch wallet portfolio
* Fetch data for graph for a given cryptocurrency
* Process buy/sell order

## Algorithm Builder
Assinged to Joshua
* Run algorithm (send generated code to cryptexVM)
* Store/fetch statisics of algorithm

## Admin
Assinged to Sanyam
* Add/Remove currency
