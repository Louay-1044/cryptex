from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import register_user, user_login, user_logout, RegisterUserClass, user_delete, user_fetchDetails, user_updateDetails
from .views import wallet_topUpBalance, wallet_fetchBalance
from .views import start_algorithm, pause_algorithm, get_algorithm_status
from .views import kill_algorithm, save_algorithm, fetch_algorithm
from .views import algorithm_sell_order, algorithm_fetch_balance, algorithm_buy_order, algorithm_fetch_holding
from .views import buy_order_liquid, buy_order_with_crypto, sell_order_crypto
from .views import (
    create_organisation,
    rename_organisation,
    delete_organisation,
    get_organisation_traders,
    get_organisation_portfolio,
    invite_trader,
    accept_invitation,
    remove_trader,
    get_trader_history,
    get_my_organisation,
    get_my_invitations,
)
from .views import list_currencies
from .views import crypt_AI_request_query


router = DefaultRouter()

urlpatterns = [
    path('', include(router.urls)),
    path('register/', register_user, name='register'),
    path('login/', user_login, name='login'),
    path('logout/', user_logout, name='logout'),
    path('currency/list/', list_currencies, name='list currency'),
    path('account/delete/', user_delete, name='delete_user'),
    path('account/fetchDetails/', user_fetchDetails, name='fetch_details'),
    path('account/updateDetails/', user_updateDetails, name='update_details'),
    path('account/topUpBalance/', wallet_topUpBalance, name='top_up_balance'),
    path('account/fetchBalance/', wallet_fetchBalance, name='fetch_balance'),
    path('buyOrder/liquid/execute/', buy_order_liquid, name='buy_order_liquid'),
    path('buyOrder/crypto/execute/', buy_order_with_crypto, name='buy_order_with_crypto'),
    path('sellOrder/execute/', sell_order_crypto, name='sell_order_crypto'),
    path('algorithm/start/', start_algorithm, name='start algorithm'),
    path('algorithm/pause/', pause_algorithm, name='pause algorithm'),
    path('algorithm/stop/', kill_algorithm, name='stop algorithm'),
    path('algorithm/save/', save_algorithm, name='save algorithm'),
    path('algorithm/fetch/', fetch_algorithm, name='fetch algorithm'),
    path('algorithm/status/', get_algorithm_status, name='algorithm status'),
    path('algorithm/buy/', algorithm_buy_order, name='algorithm buy'),
    path('algorithm/sell/', algorithm_sell_order, name='algorithm sell'),
    path('algorithm/balance/', algorithm_fetch_balance, name='algorithm balance'),
    path('algorithm/holding/', algorithm_fetch_holding, name='algorithm holding'),
    path('organisation/create/', create_organisation, name='create_organisation'),
    path('organisation/<int:org_id>/rename/', rename_organisation, name='rename_organisation'),
    path('organisation/<int:org_id>/delete/', delete_organisation, name='delete_organisation'),
    path('organisation/<int:org_id>/traders/', get_organisation_traders, name='get_organisation_traders'),
    path('organisation/<int:org_id>/portfolio/', get_organisation_portfolio, name='get_organisation_portfolio'),
    path('organisation/<int:org_id>/invite/', invite_trader, name='invite_trader'),
    path('organisation/<int:org_id>/invitation/accept/', accept_invitation, name='accept_invitation'),
    path('organisation/<int:org_id>/remove/<int:user_id>/', remove_trader, name='remove_trader'),
    path('organisation/<int:org_id>/trader/<int:user_id>/history/', get_trader_history, name='get_trader_history'),
    path('organisation/mine/', get_my_organisation, name='get_my_organisation'),
    path('organisation/invitations/', get_my_invitations, name='get_my_invitations'),
    path('cryptAI/query/', crypt_AI_request_query, name='crypt AI query'),
]
