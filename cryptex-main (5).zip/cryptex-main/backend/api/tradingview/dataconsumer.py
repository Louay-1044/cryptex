import json
import asyncio

import websockets
from channels.generic.websocket import AsyncWebsocketConsumer
from .services import crypto_data as data

# socket controller
# connect making this kinda request: ws://<host>/ws/chart/<SYMBOL>/
# eg. ws://localhost:8000/ws/chart/BTC/
class CryptoChartConsumer(AsyncWebsocketConsumer):
    """
    Handles WebSocket connections for live crypto charts.
    Connects to ws://localhost:8000/ws/chart/BTC/
    """

# defines the websocket connection protocol to frontend
# returns immediate chart data for the crypto (default 1h intervals)
# starts non-blocking fetch loop for live price fetching and sends data every couple seconds
# establishes socket connection to binance as well to fetch, reparse and send live candle data
    async def connect(self):
        self.symbol = self.scope['url_route']['kwargs']['symbol'].upper()
        print(f"🔌 WebSocket CONNECTED: {self.symbol}")

        # Accept connection
        await self.accept()

        # Send initial chart data
        await self.send_chart_history_interval("1h")

        # Start live price updates (non-blocking)
        self.price_task = asyncio.create_task(self.live_price_loop())


# used to close the websocket connection and stops the price update fetch loop
    async def disconnect(self, close_code):
        print(f"🔌 WebSocket DISCONNECTED: {self.symbol}")
        for task in getattr(self, "price_task", None), getattr(self, "candle_task", None):
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass


    # used for handling interval specific requests for new chart renders
    async def receive(self, text_data):
        data = json.loads(text_data)

        inter = data.get('interval')
        await self.send_chart_history_interval(inter)

# stops pushing live candle data, used when user changes chart interval to something other than 1m since live candle data is only for 1m candles
    async def stop_live_candle(self):
        candle_data = getattr(self, "candle_task", None)
        if candle_data:
            candle_data.cancel()
            try:
                await candle_data
            except asyncio.CancelledError:
                pass



# sends the price history candles using a specific interval, used for adjusting chart intervals
    async def send_chart_history_interval(self, inter):
        match inter:
            case "1m":
                klines = await data.get_historical_klines_1m(self.symbol)
                self.candle_task = asyncio.create_task(self.get_live_candle())
            case "5m":
                klines = await data.get_historical_klines_5m(self.symbol)
                await self.stop_live_candle()
            case "10m":
                klines = await data.get_historical_klines_10m(self.symbol)
                await self.stop_live_candle()
            case "30m":
                klines = await data.get_historical_klines_30m(self.symbol)
                await self.stop_live_candle()
            case "1h":
                klines = await data.get_historical_klines_1h(self.symbol)
                await self.stop_live_candle()
            case "6h":
                klines = await data.get_historical_klines_6h(self.symbol)
                await self.stop_live_candle()
            case "12h":
                klines = await data.get_historical_klines_12h(self.symbol)
                await self.stop_live_candle()
            case "1d":
                klines = await data.get_historical_klines_1d(self.symbol)
                await self.stop_live_candle()
            case "1w":
                klines = await data.get_historical_klines_1w(self.symbol)
                await self.stop_live_candle()
            case _:
                klines = await data.get_historical_klines_1h(self.symbol)
                await self.stop_live_candle()

        try:
            await self.send(text_data=json.dumps({
                'type': 'history',
                'symbol': self.symbol,
                'interval': inter,
                'data': klines
            }))

            print(f"📊 Sent {len(klines)} candles for {self.symbol}")

        except Exception as e:
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': str(e)
            }))



# live price updates every 5 seconds through basic rest api call
    async def live_price_loop(self):
        while True:
            try:
                ticker = await data.get_live_ticker(self.symbol)
                if not ticker:
                    await asyncio.sleep(5)
                    continue

                await self.send(text_data=json.dumps({
                    "type": "live_price",
                    "symbol": self.symbol,
                    "data": ticker,
                }))
                await asyncio.sleep(5)

            except asyncio.CancelledError:
                break
            except Exception as e:
                import traceback
                print(f"Live update error {self.symbol}: {e}")
                traceback.print_exc()
                await asyncio.sleep(10)



# fetches live most recent candle data, ONLY FOR 1M CANDLE
# constantly sends new candle data with fields specified below like highs and lows that's rendered frontend side
# establishes client websocket connection to binance
    async def get_live_candle(self):
        stream = f"{self.symbol.lower()}usdt@kline_1m"
        url = f"wss://stream.binance.com:9443/ws/{stream}"

        try:
            async with websockets.connect(url) as ws:
                async for raw in ws:
                    msg = json.loads(raw)
                    k = msg["k"]  # kline payload

                    candle = {
                        "time": int(k["t"] / 1000),
                        "open": float(k["o"]),
                        "high": float(k["h"]),
                        "low": float(k["l"]),
                        "close": float(k["c"]),
                        "volume": float(k["v"]),
                        "closed": bool(k["x"]),  # True when 1m candle finishes
                    }

                    await self.send(text_data=json.dumps({
                        "type": "live_candle",
                        "symbol": self.symbol,
                        "data": candle,
                    }))
        except asyncio.CancelledError:
            # stopped because client disconnected
            return