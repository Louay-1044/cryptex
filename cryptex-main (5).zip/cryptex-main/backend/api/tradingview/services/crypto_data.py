import aiohttp

# carries out data fetch to binance api and return the following data for each candle
async def fetch_data(url, params):
    async with aiohttp.ClientSession() as session:
        async with session.get(url, params=params) as resp:
            klines = await resp.json()
            return [{
                'time': int(kline[0] / 1000),  # TradingView format
                'open': float(kline[1]),
                'high': float(kline[2]),
                'low': float(kline[3]),
                'close': float(kline[4]),
                'volume': float(kline[5])
            } for kline in klines]


# functions defining parameters for fetching candles, different intervals fetch different amounts of candles

# past 6h
async def get_historical_klines_1m(symbol: str):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': f"{symbol}USDT",
        'interval': '1m',
        'limit': 300
    }

    return await fetch_data(url, params)

# past 12h
async def get_historical_klines_5m(symbol: str):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': f"{symbol}USDT",
        'interval': '5m',
        'limit': 144
    }

    return await fetch_data(url, params)

# past 24h
async def get_historical_klines_10m(symbol: str):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': f"{symbol}USDT",
        'interval': '10m',
        'limit': 144
    }

    return await fetch_data(url, params)

# past 3 days
async def get_historical_klines_30m(symbol: str):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': f"{symbol}USDT",
        'interval': '30m',
        'limit': 144
    }

    return await fetch_data(url, params)

# past 6 days
async def get_historical_klines_1h(symbol: str):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': f"{symbol}USDT",
        'interval': '1h',
        'limit': 144
    }

    return await fetch_data(url, params)

# past 36 days
async def get_historical_klines_6h(symbol: str):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': f"{symbol}USDT",
        'interval': '6h',
        'limit': 144
    }

    return await fetch_data(url, params)

# past 72 days
async def get_historical_klines_12h(symbol: str):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': f"{symbol}USDT",
        'interval': '12h',
        'limit': 144
    }

    return await fetch_data(url, params)

# past 144 days
async def get_historical_klines_1d(symbol: str):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': f"{symbol}USDT",
        'interval': '1d',
        'limit': 144
    }

    return await fetch_data(url, params)

# past 1008 days
async def get_historical_klines_1w(symbol: str):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        'symbol': f"{symbol}USDT",
        'interval': '1w',
        'limit': 144
    }

    return await fetch_data(url, params)


# fetches the current (almost live) price for a currency

async def get_live_ticker(symbol: str):
    """Fetch current price"""
    url = f"https://api.binance.com/api/v3/ticker/price"
    params = {'symbol': f"{symbol}USDT"}

    async with aiohttp.ClientSession() as session:
        async with session.get(url, params=params) as resp:
            try:
                data = await resp.json()
            except Exception as e:
                print("Ticker JSON error:", e)
                return None

            if "price" not in data:
                print("Ticker response missing price:", data)
                return None

            return {'price': float(data['price'])}