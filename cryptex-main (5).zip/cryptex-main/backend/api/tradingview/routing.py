from django.urls import re_path
from .dataconsumer import CryptoChartConsumer

async def debug_consumer(scope, receive, send):
    print("Matched WebSocket URL:", scope["path"])
    consumer = CryptoChartConsumer.as_asgi()
    return await consumer(scope, receive, send)

websocket_urlpatterns = [
    re_path(r'ws/chart/(?P<symbol>[A-Z]+)/$', debug_consumer),
]