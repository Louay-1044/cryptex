from decimal import Decimal
from ..models import User, CryptoOwnershipRecord, Cryptocurrency, Membership
from .orderfactory import OrderFactory
from ..tradingview.services.crypto_data import get_live_ticker
from asgiref.sync import async_to_sync

class OrderProcessingError(Exception):
    pass

# used for processing buy and sell orders, creates order record, tradehistory record, cryptoownerrecords records, and updates wallet balance
# for liquid buy pass through cryptoToSell parameter as None
class OrderProcessing:
    @staticmethod
    def process_buy_order(user: User, cryptoToBuy: Cryptocurrency, cryptoToSell: Cryptocurrency, amount: Decimal):
        # liquid buy
        if cryptoToSell is None:
            try:
                crypto_to_buy_price = Decimal(async_to_sync(get_live_ticker)(cryptoToBuy.ticker)["price"])
                membership_record = Membership.objects.filter(user=user).select_related('organisation__owner__wallet').first()
                if membership_record:
                    org = membership_record.organisation  # gets organisation wallet
                    owner = org.owner
                    wallet = owner.wallet
                else:
                    wallet = user.wallet
                total_cost = amount * crypto_to_buy_price

                if wallet.balance < total_cost:
                    raise OrderProcessingError("Insufficient funds")

                wallet.balance -= total_cost

                # creates order records first, so that if there is an error in creating the order, the wallet balance will not be updated
                order_record = OrderFactory.create_buy_order(user, cryptoToBuy, amount, crypto_to_buy_price)

                # checks if user owns currency already, if not create record, if yes update amount
                cryptoRecord = user.wallet.crypto_holdings.filter(ticker_id=cryptoToBuy.ticker).first()
                if cryptoRecord:
                    cryptoRecord.amount = cryptoRecord.amount + amount
                    cryptoRecord.save()
                else:
                    CryptoOwnershipRecord.objects.create(
                        wallet_id=wallet.trader.id,
                        ticker_id=cryptoToBuy.ticker,
                        amount=amount
                    )

                wallet.save()
                return order_record

            except Exception as e:
                raise OrderProcessingError(f"Error processing liquid buy order: {e}")

        # buying with other crypto
        else:
            try:
                crypto_to_buy_price = Decimal(async_to_sync(get_live_ticker)(cryptoToBuy.ticker)["price"])
                crypto_to_sell_price = Decimal(async_to_sync(get_live_ticker)(cryptoToSell.ticker)["price"])

                membership_record = Membership.objects.filter(user=user).select_related('organisation__owner__wallet').first()
                if membership_record:
                    org = membership_record.organisation  # gets organisation wallet
                    owner = org.owner
                    wallet = owner.wallet
                else:
                    wallet = user.wallet
                # checks to see if user has the crypto to sell
                try:
                    cryptoToSellBalance = wallet.crypto_holdings.get(ticker_id=cryptoToSell.ticker)
                except CryptoOwnershipRecord.DoesNotExist:
                    raise OrderProcessingError(f"You do not hold any {cryptoToSell.ticker} to sell.")

                cryptoAmount = cryptoToSellBalance.amount
                cryptoValue = cryptoAmount * crypto_to_sell_price

                total_cost = amount * crypto_to_buy_price

                if cryptoValue < total_cost:
                    raise OrderProcessingError("Insufficient funds")

                cryptoValue -= total_cost

                remainingAmount = cryptoValue / crypto_to_sell_price
                sold_amount = cryptoAmount - remainingAmount

                cryptoToSellBalance.amount = remainingAmount

                # creates order records first, so that if there is an error in creating the order, the wallet balance will not be updated
                order_buy_record = OrderFactory.create_buy_order(user, cryptoToBuy, amount, crypto_to_buy_price)
                OrderFactory.create_sell_order(user, cryptoToSell, sold_amount, crypto_to_sell_price)

                # checks if user owns currency already, if not create record, if yes update amount
                cryptoRecord = wallet.crypto_holdings.filter(ticker_id=cryptoToBuy.ticker).first()
                if cryptoRecord:
                    cryptoRecord.amount = cryptoRecord.amount + amount
                    cryptoRecord.save()
                else:
                    CryptoOwnershipRecord.objects.create(
                        wallet_id=wallet.trader.id,
                        ticker_id=cryptoToBuy.ticker,
                        amount=amount
                    )


                wallet.save()
                cryptoToSellBalance.save()
                return order_buy_record

            except Exception as e:
                raise OrderProcessingError(f"Error processing crypto sell and buy order: {e}")


    # sell
    @staticmethod
    def process_sell_order(user: User, cryptoToSell: Cryptocurrency, amount: Decimal):
        try:
            crypto_to_sell_price = Decimal(async_to_sync(get_live_ticker)(cryptoToSell.ticker)["price"])

            membership_record = Membership.objects.filter(user=user).select_related('organisation__owner__wallet').first()
            if membership_record:
                org = membership_record.organisation  # gets organisation wallet
                owner = org.owner
                wallet = owner.wallet
            else:
                wallet = user.wallet

            # checks to see if user has the crypto to sell
            try:
                cryptoToSellBalance = wallet.crypto_holdings.get(ticker_id=cryptoToSell.ticker)
            except CryptoOwnershipRecord.DoesNotExist:
                raise OrderProcessingError(f"You do not hold any {cryptoToSell.ticker} to sell.")

            cryptoAmount = cryptoToSellBalance.amount

            if cryptoAmount < amount:
                raise OrderProcessingError("Insufficient funds")

            remainingAmount = cryptoAmount - amount
            cryptoToSellBalance.amount = remainingAmount

            revenue = amount * crypto_to_sell_price
            wallet.balance += revenue

            # creates order records first, so that if there is an error in creating the order, the wallet balance will not be updated
            order_record = OrderFactory.create_sell_order(user, cryptoToSell, amount, crypto_to_sell_price)

            wallet.save()
            cryptoToSellBalance.save()

            if cryptoToSellBalance.amount == 0:
                cryptoToSellBalance.delete()

            return order_record

        except Exception as e:
            raise OrderProcessingError(f"Error processing sell order: {e}")
