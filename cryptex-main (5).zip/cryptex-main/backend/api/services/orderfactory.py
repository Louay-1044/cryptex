from decimal import Decimal
from ..models import User, BuyOrder, SellOrder, TradeHistory, Cryptocurrency


# Creates buy, sell order records and TradeHistory records
class OrderFactory:
    @staticmethod
    def create_buy_order(user: User, cryptocurrency: Cryptocurrency, amount: Decimal, price: Decimal) -> BuyOrder:
        buy_order_record = BuyOrder.objects.create(
            currency_bought=cryptocurrency,
            amount_bought=amount,
            buy_price=price,
            buyer_id = user.id
        )

        TradeHistory.objects.create(
            buy_order_id = buy_order_record.id,
            trader_id = user.id
        )

        return buy_order_record

    @staticmethod
    def create_sell_order(user: User, cryptocurrency: Cryptocurrency, amount: Decimal, price: Decimal) -> SellOrder:
        sell_order_record = SellOrder.objects.create(
            currency_sold=cryptocurrency,
            amount_sold=amount,
            sell_price=price,
            seller_id = user.id
        )

        TradeHistory.objects.create(
            sell_order_id = sell_order_record.id,
            trader_id = user.id
        )



        return sell_order_record
