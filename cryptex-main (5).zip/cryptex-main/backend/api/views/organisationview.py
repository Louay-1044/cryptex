from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated

from ..models import Organisation, Membership, User, TradeHistory
from ..serializers import OrganisationSerializer, MembershipSerializer
from ..serializers import UserSerializer


# ── CREATE ORGANISATION ──────────────────────────────────────────────────────

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_organisation(request):
    """Create a new organisation. The requesting user becomes the owner."""
    serializer = OrganisationSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save(owner=request.user)
        organisation = Organisation.objects.get(id=serializer.data['id'])
        # Owner is automatically added as an accepted member
        Membership.objects.get_or_create(user=request.user, organisation=organisation, defaults={'accepted': True})
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# ── RENAME ORGANISATION ──────────────────────────────────────────────────────

@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def rename_organisation(request, org_id):
    """Rename an organisation. Only the owner can rename it."""
    try:
        organisation = Organisation.objects.get(id=org_id, owner=request.user)
    except Organisation.DoesNotExist:
        return Response(
            {'error': 'Organisation not found or you are not the owner.'},
            status=status.HTTP_404_NOT_FOUND,
        )

    serializer = OrganisationSerializer(organisation, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# ── DELETE ORGANISATION ──────────────────────────────────────────────────────

@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_organisation(request, org_id):
    """Delete an organisation. Only the owner can delete it."""
    try:
        organisation = Organisation.objects.get(id=org_id, owner=request.user)
    except Organisation.DoesNotExist:
        return Response(
            {'error': 'Organisation not found or you are not the owner.'},
            status=status.HTTP_404_NOT_FOUND,
        )

    organisation.delete()
    return Response({'message': 'Organisation deleted successfully.'}, status=status.HTTP_200_OK)


# ── FETCH CURRENT TRADERS ────────────────────────────────────────────────────

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_organisation_traders(request, org_id):
    """List all accepted members (traders) of an organisation."""
    try:
        organisation = Organisation.objects.get(id=org_id)
    except Organisation.DoesNotExist:
        return Response({'error': 'Organisation not found.'}, status=status.HTTP_404_NOT_FOUND)

    is_member = Membership.objects.filter(user=request.user, organisation=organisation, accepted=True).exists()
    if not is_member and organisation.owner != request.user:
        return Response({'error': 'You are not a member of this organisation.'}, status=status.HTTP_403_FORBIDDEN)

    memberships = Membership.objects.filter(organisation=organisation, accepted=True).select_related('user')
    serializer = MembershipSerializer(memberships, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


# ── VIEW ORGANISATION WALLET PORTFOLIO ───────────────────────────────────────

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_organisation_portfolio(request, org_id):
    """
    Return the combined crypto holdings and cash balance
    for every accepted trader in the organisation.
    """
    try:
        organisation = Organisation.objects.get(id=org_id)
    except Organisation.DoesNotExist:
        return Response({'error': 'Organisation not found.'}, status=status.HTTP_404_NOT_FOUND)

    is_member = Membership.objects.filter(user=request.user, organisation=organisation, accepted=True).exists()
    if not is_member and organisation.owner != request.user:
        return Response({'error': 'You are not a member of this organisation.'}, status=status.HTTP_403_FORBIDDEN)

    membership_record = Membership.objects.filter(user=request.user).select_related('organisation__owner__wallet').first()

    org = membership_record.organisation  # gets organisation wallet
    owner = org.owner
    wallet = owner.wallet
    crypto = wallet.crypto_holdings.all().values("amount", "ticker_id")
    crypto_list = list(crypto)

    return Response({'organisation': org.name, 'portfolio': crypto_list, 'balance': wallet.balance}, status=status.HTTP_200_OK)


# ── INVITE TRADER ────────────────────────────────────────────────────────────

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def invite_trader(request, org_id):
    """
    Invite a trader (by username) to the organisation.
    Only the owner can send invitations.
    Creates a pending Membership (accepted=False) - the user must accept separately.
    Expected body: { "username": "<username>" }
    """
    try:
        organisation = Organisation.objects.get(id=org_id, owner=request.user)
    except Organisation.DoesNotExist:
        return Response(
            {'error': 'Organisation not found or you are not the owner.'},
            status=status.HTTP_404_NOT_FOUND,
        )

    username = request.data.get('username')
    if not username:
        return Response({'error': 'Username is required.'}, status=status.HTTP_400_BAD_REQUEST)

    try:
        trader = User.objects.get(username=username)
    except User.DoesNotExist:
        return Response({'error': f'User "{username}" not found.'}, status=status.HTTP_404_NOT_FOUND)

    existing = Membership.objects.filter(user=trader, organisation=organisation).first()
    if existing:
        if existing.accepted:
            return Response({'error': f'"{username}" is already a member.'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({'error': f'"{username}" already has a pending invitation.'}, status=status.HTTP_400_BAD_REQUEST)

    # Create a PENDING invitation (accepted=False)
    membership = Membership.objects.create(user=trader, organisation=organisation, accepted=False)
    serializer = MembershipSerializer(membership)
    return Response(serializer.data, status=status.HTTP_201_CREATED)


# ── ACCEPT INVITATION ────────────────────────────────────────────────────────

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def accept_invitation(request, org_id):
    """
    Accept a pending invitation to an organisation.
    The requesting user must have a pending (accepted=False) membership.
    """
    try:
        organisation = Organisation.objects.get(id=org_id)
    except Organisation.DoesNotExist:
        return Response({'error': 'Organisation not found.'}, status=status.HTTP_404_NOT_FOUND)

    try:
        membership = Membership.objects.get(user=request.user, organisation=organisation)
    except Membership.DoesNotExist:
        return Response({'error': 'You have not been invited to this organisation.'}, status=status.HTTP_404_NOT_FOUND)

    if membership.accepted:
        return Response({'error': 'You are already a member of this organisation.'}, status=status.HTTP_400_BAD_REQUEST)

    membership.accepted = True
    membership.save()
    serializer = MembershipSerializer(membership)
    return Response(serializer.data, status=status.HTTP_200_OK)


# ── REMOVE TRADER ────────────────────────────────────────────────────────────

@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def remove_trader(request, org_id, user_id):
    """
    Remove a trader from the organisation.
    Only the owner can remove members; a member can remove themselves.
    """
    try:
        organisation = Organisation.objects.get(id=org_id)
    except Organisation.DoesNotExist:
        return Response({'error': 'Organisation not found.'}, status=status.HTTP_404_NOT_FOUND)

    if organisation.owner != request.user and request.user.id != user_id:
        return Response({'error': 'Permission denied.'}, status=status.HTTP_403_FORBIDDEN)

    try:
        membership = Membership.objects.get(organisation=organisation, user_id=user_id)
    except Membership.DoesNotExist:
        return Response({'error': 'Trader is not a member of this organisation.'}, status=status.HTTP_404_NOT_FOUND)

    if membership.user == organisation.owner:
        return Response({'error': 'Cannot remove the owner from the organisation.'}, status=status.HTTP_400_BAD_REQUEST)

    membership.delete()
    return Response({'message': 'Trader removed successfully.'}, status=status.HTTP_200_OK)


# ── VIEW TRADE HISTORY OF A TRADER ───────────────────────────────────────────

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_trader_history(request, org_id, user_id):
    """
    View the trade history of a specific trader within the organisation.
    Only accessible by the organisation owner.
    """
    try:
        organisation = Organisation.objects.get(id=org_id, owner=request.user)
    except Organisation.DoesNotExist:
        return Response(
            {'error': 'Organisation not found or you are not the owner.'},
            status=status.HTTP_404_NOT_FOUND,
        )

    if not Membership.objects.filter(organisation=organisation, user_id=user_id, accepted=True).exists():
        return Response({'error': 'Trader is not a member of this organisation.'}, status=status.HTTP_404_NOT_FOUND)

    history = TradeHistory.objects.filter(trader_id=user_id).select_related('buy_order', 'sell_order')

    result = []
    for record in history:
        if record.buy_order:
            result.append({
                'type': 'buy',
                'currency': record.buy_order.currency_bought.ticker,
                'amount': str(record.buy_order.amount_bought),
                'price': str(record.buy_order.buy_price),
                'datetime': record.buy_order.buy_date_time,
            })
        elif record.sell_order:
            result.append({
                'type': 'sell',
                'currency': record.sell_order.currency_sold.ticker,
                'amount': str(record.sell_order.amount_sold),
                'price': str(record.sell_order.sell_price),
                'datetime': record.sell_order.sell_date_time,
            })

    return Response({'trader_id': user_id, 'trade_history': result}, status=status.HTTP_200_OK)
# ── GET CURRENT USER'S ORGANISATION ─────────────────────────────────────────

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_my_organisation(request):
    """
    Returns the organisation the current user belongs to or owns.
    Returns 404 if the user is not part of any organisation.
    """
    membership = Membership.objects.filter(user=request.user, accepted=True).select_related('organisation').first()
    if not membership:
        return Response({'error': 'You are not part of any organisation.'}, status=status.HTTP_404_NOT_FOUND)

    serializer = OrganisationSerializer(membership.organisation)
    return Response(serializer.data, status=status.HTTP_200_OK)


# ── GET PENDING INVITATIONS ──────────────────────────────────────────────────

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_my_invitations(request):
    """
    Returns all pending invitations for the current user.
    """
    invitations = Membership.objects.filter(user=request.user, accepted=False).select_related('organisation')
    serializer = MembershipSerializer(invitations, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)