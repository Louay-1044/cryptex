from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from ..models import Membership

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def wallet_topUpBalance(request):
    try:
        wallet = request.user.wallet
        wallet.updateBalance(1000.00)
        return Response({'wallet_status': 'updated'}, status=status.HTTP_200_OK)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def wallet_fetchBalance(request):
    try:
        membership_record = Membership.objects.filter(user=request.user).select_related('organisation__owner__wallet').first()
        if membership_record is None: # they are not in an organisation
            wallet = request.user.wallet
            crypto = wallet.crypto_holdings.all().values("amount", "ticker_id")
            crypto_list = list(crypto)
            return Response({'wallet_balance': wallet.balance, 'wallet_crypto': crypto_list, 'type': 'personal'}, status=status.HTTP_200_OK)
        else:
            org = membership_record.organisation # gets organisation wallet
            owner = org.owner
            wallet = owner.wallet
            crypto = wallet.crypto_holdings.all().values("amount", "ticker_id")
            crypto_list = list(crypto)
            return Response({'wallet_balance': wallet.balance, 'wallet_crypto': crypto_list, 'type': 'organisation'}, status=status.HTTP_200_OK)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

