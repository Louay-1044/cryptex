from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from ..cryptAI.chat import query_with_code, query_with_market


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def crypt_AI_request_query(request):
    try:
        data = request.data
        if data.get('type') == 'code':
            resp = query_with_code(data.get('prompt'), data.get('code'))
            return Response({'response': resp})

        elif data.get('type') == 'market':
            resp = query_with_market(data.get('prompt'))
            return Response({'response': resp})

        else:
            return Response({'error': 'Bad request parameters'}, status=status.HTTP_400_BAD_REQUEST)

    except Exception as e:
        print("VIEW ERROR:", repr(e))
        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

