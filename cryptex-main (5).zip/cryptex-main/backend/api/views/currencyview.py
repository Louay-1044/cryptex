from rest_framework.decorators import api_view
from rest_framework.response import Response
from ..models import Cryptocurrency


# REPONSE FORMAT:
# [
#    {"ticker": "BTC", "name": "Bitcoin"},
#    {"ticker": "ETH", "name": "Ethereum"},
# ]
@api_view(['GET'])
def list_currencies(request):
    currencies = Cryptocurrency.objects.all()
    data = [
        {"ticker": c.ticker, "name": c.name}
        for c in currencies
    ]
    return Response(data)
