from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from ..serializers import BuyOrderWithCryptoSerializer, BuyOrderLiquidSerializer, SellOrderCryptoSerializer


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def buy_order_liquid(request):
    serializer = BuyOrderLiquidSerializer(
        data=request.data,
        context={"user": request.user}
    )
    if serializer.is_valid(raise_exception=True):
        order = serializer.save()
        return Response({"message": "Buy order executed successfully."})
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def buy_order_with_crypto(request):
    serializer = BuyOrderWithCryptoSerializer(
        data=request.data,
        context={"user": request.user}
    )
    if serializer.is_valid(raise_exception=True):
        order = serializer.save()
        return Response({"message": "Buy order with crypto executed successfully."})
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



@api_view(['POST'])
@permission_classes([IsAuthenticated])
def sell_order_crypto(request):
    serializer = SellOrderCryptoSerializer(
        data=request.data,
        context={"user": request.user}
    )
    if serializer.is_valid(raise_exception=True):
        order = serializer.save()
        return Response({"message": "Sell order executed successfully."})
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)