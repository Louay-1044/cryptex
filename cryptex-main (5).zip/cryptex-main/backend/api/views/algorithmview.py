import os
import threading
import logging
import signal
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.permissions import IsAuthenticated
from django.core.cache import cache
import uuid
from ..models import Algorithm, AlgorithmToken
from ..permissions import AlgorithmTokenAuthentication, IsAlgorithm
from ..serializers import BuyOrderLiquidSerializer, SellOrderCryptoSerializer

logger = logging.getLogger(__name__)


# POST /api/algorithms/start
# Creates .ctx file, spawns cryptexVM, stores record, starts monitor thread.
# Expects JSON body: { "source": "<vm source code>", "blocks_json": { ... } }
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def start_algorithm(request):
    user_id = request.user.id
    location = f"/app/shared/files/{user_id}.ctx"

    # Delete any existing record for this user
    try:
        existing = Algorithm.objects.get(owner=request.user)
        existing.delete()
    except Algorithm.DoesNotExist:
        pass

    try:
        if not os.path.exists("/app/shared/files/"):
            os.makedirs("/app/shared/files/", exist_ok=True)

        source = request.data.get('source', '')
        blocks_json = request.data.get('blocks_json', {})
        print(source)

        with open(location, mode='w+', encoding="utf-8") as file:
            file.write(source)

        executable = "/app/shared/bin/cryptexVM"

        # CREATE A NEW TOKEN FOR USER AND ADD AS ENV VAR
        algorithm_token = AlgorithmToken()
        algorithm_token.user = request.user
        algorithm_token.name = f"Algorithm Process {uuid.uuid4()}"
        raw_key = algorithm_token.generate_key()
        algorithm_token.set_key(raw_key)
        algorithm_token.save()

        token_cache_key = f"algorithm_token_{user_id}_{uuid.uuid4()}"
        cache.set(token_cache_key, raw_key, timeout=None)

        env = os.environ.copy()
        env['AUTH_TOKEN'] = raw_key
        env['USER_ID'] = str(user_id)

        pid = os.posix_spawn(
            executable,
            [executable, location],
            env,
        )

        algorithm = Algorithm.objects.create(
            owner=request.user,
            pid=pid,
            status=Algorithm.RUNNING,
            stored_state=blocks_json
        )
        algorithm.save()

        threading.Thread(
            target=monitor_algorithm,
            args=(pid, algorithm.id, location, algorithm_token.id, token_cache_key),
            daemon=True
        ).start()

        return Response(
            {
                "status": algorithm.status,
                "start_time": algorithm.start_time,
            },
            status=status.HTTP_201_CREATED,
        )

    except FileNotFoundError:
        logger.error(f"File not found: {location}")
        return Response(
            {"error": "Failed to start algorithm"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )
    except OSError as e:
        logger.error(f"Failed to spawn process: {e}")
        return Response(
            {"error": "Failed to start algorithm"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


# MONITOR A RUNNING ALGORITHM FROM PID
def monitor_algorithm(pid, algorithm_id, location, token_id, token_cache_key):
    try:
        _, status = os.waitpid(pid, 0)
        algorithm = Algorithm.objects.get(id=algorithm_id)
        print(f"Algorithm: {algorithm_id} exited with satus: {status}")

        if status != 0 and status != 9:
            # SET STATUS TO ERROR
            algorithm.status = Algorithm.ERROR
            algorithm.error_message = ""
        else:
            algorithm.status = Algorithm.STOPPED
            COMPILE_ERROR = "Compilation Error: Is the algorithm malformed?"
            RUNTIME_ERROR = "Runtime Error: Algorithm stopped during runtime!"
            UNKOWN_ERROR = "Unkown Error: An unkown error occured!"
            if (status == 19200):
                algorithm.error_message = COMPILE_ERROR
            elif (status == 16640):
                algorithm.error_message = RUNTIME_ERROR
            else:
                algorithm.error_message = UNKOWN_ERROR

        from django.utils import timezone
        algorithm.end_time = timezone.now()
        algorithm.save()

    except Exception as e:
        logger.error(f"Error monitoring algorithm: {e}")
    finally:
        try:
            os.remove(location)
        except OSError:
            pass
        # DELETE TOKEN
        cache.delete(token_cache_key)
        AlgorithmToken.objects.filter(id=token_id).delete()


# GET /api/algorithms/status
# Returns current status + timestamps so the frontend poller stays up-to-date.
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_algorithm_status(request):
    try:
        algorithm = Algorithm.objects.get(owner=request.user)
    except Algorithm.DoesNotExist:
        return Response(
            {"error": "No such algorithm exists"},
            status=status.HTTP_404_NOT_FOUND,
        )

    return Response(
        {
            "id": algorithm.id,
            "status": algorithm.status,
            "start_time": algorithm.start_time,
            "end_time": algorithm.end_time,
            "error_message": algorithm.error_message,
        },
        status=status.HTTP_200_OK,
    )


# POST /api/algorithms/pause/
# Toggles between SIGSTOP (pause) and SIGCONT (resume).
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def pause_algorithm(request):
    try:
        algorithm = Algorithm.objects.get(owner=request.user)
    except Algorithm.DoesNotExist:
        return Response(
            {"error": "No such algorithm exists"},
            status=status.HTTP_404_NOT_FOUND,
        )

    algo_status = algorithm.status
    try:
        if algo_status == Algorithm.RUNNING:
            os.kill(algorithm.pid, signal.SIGSTOP)
            algorithm.status = Algorithm.PAUSED
            algorithm.save()
            return Response(
                {"success": "Algorithm paused"},
                status=status.HTTP_200_OK,
            )
        elif algo_status == Algorithm.PAUSED:
            os.kill(algorithm.pid, signal.SIGCONT)
            algorithm.status = Algorithm.RUNNING
            algorithm.save()
            return Response(
                {"success": "Algorithm running"},
                status=status.HTTP_200_OK,
            )
        else:
            return Response(
                {"error": "Algorithm is not running or paused"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    except ProcessLookupError as e:
        logger.error(f"ProcessLookupError: failed to find process: {e}")
        return Response(
            {"error": "Algorithm process not found"},
            status=status.HTTP_404_NOT_FOUND,
        )
    except OSError as e:
        logger.error(f"OSError: failed to pause process: {e}")
        return Response(
            {"error": "Unexpected error"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


# POST /api/algorithms/stop/
# Sends SIGTERM to the process and marks it stopped.
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def kill_algorithm(request):
    try:
        algorithm = Algorithm.objects.get(owner=request.user)
    except Algorithm.DoesNotExist:
        return Response(
            {"error": "No such algorithm exists"},
            status=status.HTTP_404_NOT_FOUND,
        )

    algo_status = algorithm.status
    if algo_status != Algorithm.RUNNING and algo_status != Algorithm.PAUSED:
        return Response(
            {"error": "Algorithm is not running"},
            status=status.HTTP_400_BAD_REQUEST
        )

    if algorithm.token_cache_key:
        cache.delete(algorithm.token_cache_key)
    if algorithm.algorithm_token_id:
        AlgorithmToken.objects.filter(id=algorithm.algorithm_token_id).delete()

    try:
        os.kill(algorithm.pid, signal.SIGKILL)
        algorithm.status = Algorithm.STOPPED
        algorithm.save()
        return Response(
            {"success": "Algorithm stopped"},
            status=status.HTTP_200_OK
        )
    except ProcessLookupError as e:
        logger.error(f"ProcessLookupError: Failed to find process: {e}")
        return Response(
            {"error": "Algorithm not found"},
            status=status.HTTP_404_NOT_FOUND
        )
    except PermissionError as e:
        logger.error(f"PermissionError: Insufficient privileges to kill process {algorithm.pid}: {e}")
        return Response(
            {"error": "Permission denied to terminate process"},
            status=status.HTTP_403_FORBIDDEN
        )
    except OSError as e:
        logger.error(f"OSError: Failed to pause proccess: {e}")
        return Response(
            {"error": "Something unexpected happended"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


# RETURNS ALGORITHM STATUS AS REPONSE
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def stop_algorithm(request):
    try:
        algorithm = Algorithm.objects.get(owner=request.user)
    except Algorithm.DoesNotExist:
        return Response(
            {"error": "No such algorithm exists"},
            status=status.HTTP_404_NOT_FOUND,
        )

    if algorithm.status not in (Algorithm.RUNNING, Algorithm.PAUSED):
        return Response(
            {"error": "Algorithm is not running or paused"},
            status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        os.kill(algorithm.pid, signal.SIGTERM)
        algorithm.status = Algorithm.STOPPED

        from django.utils import timezone
        algorithm.end_time = timezone.now()
        algorithm.save()

        return Response(
            {"success": "Algorithm stopped"},
            status=status.HTTP_200_OK,
        )

    except ProcessLookupError as e:
        logger.error(f"ProcessLookupError: {e}")
        return Response(
            {"error": "Algorithm process not found"},
            status=status.HTTP_404_NOT_FOUND,
        )
    except OSError as e:
        logger.error(f"OSError: {e}")
        return Response(
            {"error": "Unexpected error"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


# SAVE THE ALGORITHM STATE
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def save_algorithm(request):
    algorithm, created = Algorithm.objects.get_or_create(
        owner=request.user,
        defaults={'status': Algorithm.STOPPED}
    )

    algorithm.stored_state = request.data.get('blocks_json', '')
    algorithm.save()

    message = "created" if created else "updated"
    return Response(
        {"status": message},
        status=status.HTTP_201_CREATED if created else status.HTTP_200_OK
    )


# FETCH THE ALGORITHM STATE
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def fetch_algorithm(request):
    try:
        algorithm = Algorithm.objects.get(owner=request.user)
    except Algorithm.DoesNotExist:
        return Response(
            {"error": "No algorithm found for this user"},
            status=status.HTTP_404_NOT_FOUND
        )

    return Response(
        {
            "status": "fetched",
            "blocks_json": algorithm.stored_state,
            "algorithm_status": algorithm.status
        },
        status=status.HTTP_200_OK
    )


# ----------------------------------------------------------------------------------------
#                   ALGORITHM ENDPOINTS FOR BUYING AND SELLING
# ----------------------------------------------------------------------------------------


# BUYING
@api_view(['POST'])
@authentication_classes([AlgorithmTokenAuthentication])
@permission_classes([IsAlgorithm])
def algorithm_buy_order(request):
    serializer = BuyOrderLiquidSerializer(
        data=request.data,
        context={"user": request.user}
    )
    try:
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response({"message": "Buy order executed successfully."})
    except Exception as e:
        print(e)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# SELLING
@api_view(['POST'])
@authentication_classes([AlgorithmTokenAuthentication])
@permission_classes([IsAlgorithm])
def algorithm_sell_order(request):
    serializer = SellOrderCryptoSerializer(
        data=request.data,
        context={"user": request.user}
    )

    try:
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Buy order executed successfully."})
    except Exception as e:
        if str(request.data.get('amount_sold')) == "0":
            return Response({"message": "Buy order executed successfully."})
        else:
            print(e)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# BALANCE
@api_view(['GET'])
@authentication_classes([AlgorithmTokenAuthentication])
@permission_classes([IsAlgorithm])
def algorithm_fetch_balance(request):
    try:
        wallet = request.user.wallet
        return Response({'wallet_balance': wallet.balance})
    except Exception:
        return Response({
            'error': "Unable to fetch balance"},
            status=status.HTTP_400_BAD_REQUEST
        )


# AMOUNT OF A CURRENCY
@api_view(['GET'])
@authentication_classes([AlgorithmTokenAuthentication])
@permission_classes([IsAlgorithm])
def algorithm_fetch_holding(request):
    try:
        ticker = request.query_params.get('ticker')

        if not ticker:
            return Response({'error': 'ticker parameter is required'}, status=status.HTTP_400_BAD_REQUEST)

        wallet = request.user.wallet
        holding = wallet.crypto_holdings.filter(ticker_id=ticker).values("amount").first()
        amount = holding['amount'] if holding else 0

        return Response({'ticker': ticker, 'amount': amount}, status=status.HTTP_200_OK)

    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
